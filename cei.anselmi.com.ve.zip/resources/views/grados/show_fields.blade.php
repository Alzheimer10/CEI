<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $grado->id !!}</p>
</div>

<!-- Grado Field -->
<div class="form-group">
    {!! Form::label('grado', 'Grado:') !!}
    <p>{!! $grado->grado !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $grado->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $grado->updated_at !!}</p>
</div>

