<div class="panel-body">
	<ul>
		<li>PASO 1: Abrir la pestaña "Estudiantes"</li>
		<li>PASO 2: Click en "Ver todos"</li>
	</ul>
	<img src="{{ asset('documentacion/estudiante/verEstudiantes.jpg') }}" width="100%">
</div>