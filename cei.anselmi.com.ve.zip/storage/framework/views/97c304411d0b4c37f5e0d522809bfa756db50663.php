<!-- Nombre Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nombre', 'Nombre:'); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

</div>

<!-- Tlf Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('Telefono', 'Tlf:'); ?>

    <?php echo Form::text('tlf', null, ['class' => 'form-control']); ?>

</div>

<!-- Estudiante Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estudiante_id', 'Estudiante:'); ?>

    <?php echo Form::select('estudiante_id', \App\Models\estudiante::all()->pluck('nombre','id'), null, ['class' => 'form-control selectpicker', 'required' => 'true', 'data-live-search' => 'true']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <?php if( Request::is('representantes/*/edit') ): ?>
        <a href="<?php echo route('representantes.index'); ?>" class="btn btn-default"><?php echo app('translator')->getFromJson('app.cancel'); ?></a>
    <?php else: ?>
        <a href="#" class="btn btn-default" data-dismiss="modal" aria-label="Close"><?php echo app('translator')->getFromJson('app.cancel'); ?></a>
    <?php endif; ?>
</div>