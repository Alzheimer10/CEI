<!-- Nombre Field -->
<div class="form-group col-sm-6 <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <?php echo Form::label('name', 'Nombre:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6 <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<?php if(Request::is('users/create')): ?>
<!-- Nombre Field -->
<div class="form-group col-sm-6 <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
    <?php echo Form::label('password', 'Contraseña:'); ?>

    <?php echo Form::password('password', ['class' => 'form-control']); ?>

</div>

<!-- Nombre Field -->
<div class="form-group col-sm-6 <?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
    <?php echo Form::label('password_confirmation', 'Contraseña:'); ?>

    <?php echo Form::password('password_confirmation', ['class' => 'form-control']); ?>

</div>
<?php endif; ?>
<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('users.index'); ?>" class="btn btn-default"><?php echo app('translator')->getFromJson('app.cancel'); ?></a>
</div>
