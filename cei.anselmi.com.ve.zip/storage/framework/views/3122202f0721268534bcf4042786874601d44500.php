<div class="col-xs-12">
  <!-- Widget: user widget style 1 -->
  <div class="box box-widget widget-user">
    <!-- Add the bg color to the header using any of the bg-* classes -->
    <div class="widget-user-header bg-aqua-active">
      <h3 class="widget-user-username"><?php echo $estudiante->nombre; ?> <?php echo $estudiante->apellido; ?> (<?php echo $estudiante->id; ?>)</h3>
      <?php if(!Auth::guest()): ?>
        <span class="pull-right">
          <?php echo Form::open(['route' => ['estudiantes.destroy', $estudiante->id], 'method' => 'delete']); ?>

            <div class='btn-group'>
                <a href="<?php echo route('estudiantes.edit', [$estudiante->id]); ?>" class='btn btn-primary btn-sm'><i class="glyphicon glyphicon-edit"></i>
                  Editar
                </a>

                <a href="<?php echo route('boletas.create', ['estudiante_id'=>$estudiante->id]); ?>" class='btn btn-warning btn-sm'><i class="fa fa-book" aria-hidden="true"></i>
                  Añadir Boleta
                </a>

            </div>
          <?php echo Form::close(); ?>

        </span>
      <?php endif; ?>
      <h5 class="widget-user-desc"><?php echo $estudiante->email; ?></h5>
      <h5 class="widget-user-desc">
        <?php if($estudiante->sexo == 'M'): ?>
             <i class="fa fa-mars" aria-hidden="true"></i> M
        <?php else: ?>
             <i class="fa fa-venus" aria-hidden="true"></i> F
        <?php endif; ?>
         | CI:<b><?php echo e($estudiante->ci); ?></b>
      </h5>
      <h5 class="widget-user-desc pull-right">Ultima Actualizacion: <?php echo $estudiante->updated_at->format('d-M-Y'); ?></h5>
    </div>
    <div class="widget-user-image">
      <img class="img-circle" src="../img/default_avatar.jpg" alt="User Avatar">
    </div>
    <div class="box-footer">
      <div class="row">
        <div class="col-sm-3 border-right">
          <div class="description-block">
            <h5 class="description-header">Fecha de nacimiento</h5>
            <span class="description-text"><?php echo $estudiante->fechaNacimiento->format('d-M-Y'); ?></span>
          </div>
          <!-- /.description-block -->
        </div>
        <!-- /.col -->
        <div class="col-sm-3 border-right">
          <div class="description-block">
            <h5 class="description-header">Edad</h5>
            <span class="description-text"><?php echo e($estudiante->edad); ?></span>
          </div>
          <!-- /.description-block -->
        </div>
        <!-- /.col -->
        <div class="col-sm-3">
          <div class="description-block">
            <h5 class="description-header">Sexo</h5>
            <span class="description-text">
                <?php if($estudiante->sexo == 'M'): ?>
                    <i class="fa fa-mars" aria-hidden="true"></i> MASCULINO
                <?php else: ?>
                    <i class="fa fa-venus" aria-hidden="true"></i> FEMENINO
                <?php endif; ?>

            </span>
          </div>
          <!-- /.description-block -->
        </div>
        <!-- /.col -->
        <div class="col-sm-3">
          <div class="description-block">
            <h5 class="description-header">Grado</h5>
            <span class="description-text"><?php if(isset($estudiante->seccion)): ?> <?php echo $estudiante->seccion->nombre; ?> <?php else: ?> N/A <?php endif; ?></span>
          </div>
          <!-- /.description-block -->
        </div>
        <!-- /.col -->

        <!-- /.col -->
        <div class="col-sm-12">
          <div class="description-block">
            <h5 class="description-header">REPRESENTANTES</h5>
                <?php $__currentLoopData = $estudiante->representantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $representante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="description-text">
                       <b><?php echo e($representante->nombre); ?></b>
                       <?php echo e($representante->email); ?>

                       <?php echo e($representante->tlf); ?>

                    </span><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <!-- /.description-block -->
        </div>

      </div>
      <!-- /.row -->
    </div>
  </div>
  <!-- /.widget-user -->
</div>

<?php if($estudiante->acceso==0): ?>
  <div style="padding: 20px 30px; margin-bottom: 20px;background: #F44336;text-align: center; z-index: 999999; font-size: 16px; font-weight: 600;">
    <a href="#" style="color: rgba(255, 255, 255, 0.9); display: inline-block; margin-right: 10px; text-decoration: none;">Debe cancelar la mensualidad para poder ver las boletas!</a>
  </div>
<?php endif; ?>
<?php if( !Auth::guest() || $estudiante->acceso==1 ): ?>
<div class="col-xs-12">
  <div class="box box-default box-solid">
    <div class="box-header with-border">
      <h3 class="box-title">Historial</h3>
      <div class="box-tools pull-right">
      </div>
      <!-- /.box-tools -->
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <?php $__currentLoopData = $estudiante->boletas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boleta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12">
            <ul class="timeline">
                    <li class="time-label">
                          <span class="bg-blue">
                            <?php echo e($boleta->created_at->format('d-M-Y')); ?>

                          </span>
                    </li>
                    <li>
                        <i class="fa fa-book bg-purple"></i>
                        <div class="timeline-item">
                          <span class="time"><i class="fa fa-clock-o"></i></span>
                          <h3 class="timeline-header"><a href="#">Boleta</a> <?php echo e($boleta->updated_at); ?></h3>
                            <div class="timeline-body col-sm-3">
                                <span class="mailbox-attachment-icon" style="padding: "><embed src="<?php echo e(url($boleta->boleta)); ?>#toolbar=0" width="   100" style="display: block;width: 100%;"></span>
                                <div class="mailbox-attachment-info">
                                  <a href="<?php echo e(url($boleta->boleta)); ?>" target="_blank" class="mailbox-attachment-name"><i class="fa  fa-paperclip"></i> Boleta_.pdf</a>
                                      <span class="mailbox-attachment-size" style="display: initial;">
                                          <a href="<?php echo e(url($boleta->boleta)); ?>" class="btn btn-default btn-xs pull-right"
                                           download="boleta_<?php echo e($estudiante->updated_at->format('d-M-Y-h:m:s')); ?>"><i class="fa fa-cloud-download"></i></a>
                                      </span>
                                </div>
                            </div>
                            <div class="col-sm-9">
                                <div class="box">
                                    <?php echo e($boleta->observacion); ?>

                                </div>
                            </div>
                        </div>
                    </li>
            </ul>
        </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->
</div>
<?php endif; ?>