<div class="panel-body">
	<ul>
		<li>PASO 1: Abrir la pestaña "Estudiantes"</li>
		<li>PASO 2: Click en "Agregar"</li>
	</ul>
	<img src="<?php echo e(asset('documentacion/estudiante/addEstudiante.jpg')); ?>" width="100%">
</div>