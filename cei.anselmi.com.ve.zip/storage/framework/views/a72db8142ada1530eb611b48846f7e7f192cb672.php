<?php $appController = app('App\Services\appController'); ?>
<!-- A Escolar Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('a_escolar', 'Año Escolar:'); ?>

    <?php echo Form::select('a_escolar', $appController->Anos(), null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- Trimestre Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('trimestre', 'Trimestre:'); ?>

    <?php echo Form::select('trimestre', ['ENERO - ABRIL' => 'ENERO - ABRIL', 'MAYO - JULIO' => 'MAYO - JULIO', 'SEPTIEMBRE - DICIEMBRE' =>'SEPTIEMBRE - DICIEMBRE'], null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- Estudiante Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estudiante_id', 'Estudiante:'); ?>

    <select name="estudiante_id" id="estudiante_id" class="form-control selectpicker" required="true" data-live-search='true'>
        <option value="">Estudiante</option>
        <?php $__currentLoopData = \App\Models\estudiante::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($boleta)): ?>
                <?php if($estudiante->id==$boleta->estudiante_id): ?>
                    <option value="<?php echo e($estudiante->id); ?>" selected="true"><?php echo e($estudiante->nombre); ?>, <?php echo e($estudiante->apellido); ?></option>
                <?php endif; ?>
            <?php endif; ?>
            <option value="<?php echo e($estudiante->id); ?>"><?php echo e($estudiante->nombre); ?>, <?php echo e($estudiante->apellido); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<!-- Seccion Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('seccion_id', 'Seccion:'); ?>

    <?php echo Form::select('seccion_id', \App\Models\seccion::all()->pluck('seccion','id'), null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>



<!-- Url Field -->
<?php if(isset($boleta)): ?>
    <div class="box-body col-sm-12">
        <div class="box">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input id="file" name="file" type="file">
        </div>
    </div>
<?php else: ?>
    <div class="box-body col-sm-12">
        <div class="box">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input id="file" name="file" type="file" required>
        </div>
    </div>
<?php endif; ?>
<!-- Observacion Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('observacion', 'Observacion:'); ?>

    <?php echo Form::textarea('observacion', null, ['class' => 'form-control', 'maxlength' => '500','rows' => '5', 'title' => 'Maximo de carácteres (500)']); ?>

</div>


<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <?php if( Request::is('boletas/*/edit')): ?>
        <a href="<?php echo route('boletas.index'); ?>" class="btn btn-default"><?php echo app('translator')->getFromJson('app.cancel'); ?></a>
    <?php elseif(Request::is('boletas/create')): ?>
        <a href="<?php echo route('estudiantes.index'); ?>" class="btn btn-default"><?php echo app('translator')->getFromJson('app.cancel'); ?></a>
    <?php else: ?>
        <a href="#" class="btn btn-default" data-dismiss="modal" aria-label="Close">Cancel</a>
    <?php endif; ?>
</div>
