<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $boleta->id; ?></p>
</div>

<!-- A Escolar Field -->
<div class="form-group">
    <?php echo Form::label('a_escolar', 'Año Escolar:'); ?>

    <p><?php echo $boleta->a_escolar; ?></p>
</div>

<!-- Trimestre Field -->
<div class="form-group">
    <?php echo Form::label('trimestre', 'Trimestre:'); ?>

    <p><?php echo $boleta->trimestre; ?></p>
</div>

<!-- Boleta Field -->
<div class="form-group">
    <?php echo Form::label('boleta', 'Boleta:'); ?>

    <p><?php echo $boleta->boleta; ?></p>
</div>

<!-- Observacion Field -->
<div class="form-group">
    <?php echo Form::label('observacion', 'Observacion:'); ?>

    <p><?php echo $boleta->observacion; ?></p>
</div>

<!-- Estudiante Id Field -->
<div class="form-group">
    <?php echo Form::label('estudiante_id', 'Estudiante Id:'); ?>

    <p><?php echo $boleta->estudiante_id; ?></p>
</div>

<!-- Seccion Id Field -->
<div class="form-group">
    <?php echo Form::label('seccion_id', 'Seccion Id:'); ?>

    <p><?php echo $boleta->seccion_id; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $boleta->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $boleta->updated_at; ?></p>
</div>

