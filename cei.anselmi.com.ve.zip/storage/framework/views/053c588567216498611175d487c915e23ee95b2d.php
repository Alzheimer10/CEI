<!-- Nombre Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nombre', 'Nombre:'); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control','required' => 'true']); ?>

</div>

<!-- Apellido Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('apellido', 'Apellido:'); ?>

    <?php echo Form::text('apellido', null, ['class' => 'form-control','required' => 'true']); ?>

</div>

<!-- Fechanacimiento Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('fechaNacimiento', 'Fecha Nacimiento:'); ?>

    <?php if( \Request::route()->getName()=='estudiantes.edit' ): ?>
        <?php echo Form::date('fechaNacimiento', $estudiante->fechaNacimiento->format('Y-m-d'), ['class' => 'form-control','required' => 'true']); ?>

    <?php else: ?>
        <?php echo Form::date('fechaNacimiento', null, ['class' => 'form-control','required' => 'true']); ?>

    <?php endif; ?>
</div>

<!-- Ci Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ci', 'Ci:'); ?>

    <?php echo Form::text('ci', null, ['class' => 'form-control','required' => 'true']); ?>

</div>

<!-- Sexo Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('sexo', 'Sexo:'); ?>

    <label class="radio-inline">
        <?php echo Form::radio('sexo', "M", null,['required' => 'true']); ?> M
    </label>

    <label class="radio-inline">
        <?php echo Form::radio('sexo', "F", null); ?> F
    </label>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <?php if( Request::is('estudiantes/*/edit') ): ?>
        <a href="<?php echo route('estudiantes.index'); ?>" class="btn btn-default"><?php echo app('translator')->getFromJson('app.cancel'); ?></a>
    <?php else: ?>
        <a href="#" class="btn btn-default" data-dismiss="modal" aria-label="Close"><?php echo app('translator')->getFromJson('app.cancel'); ?></a>
    <?php endif; ?>
</div>
