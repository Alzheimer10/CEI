<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $seccion->id; ?></p>
</div>

<!-- Seccion Field -->
<div class="form-group">
    <?php echo Form::label('seccion', 'Seccion:'); ?>

    <p><?php echo $seccion->seccion; ?></p>
</div>

<!-- Grado Id Field -->
<div class="form-group">
    <?php echo Form::label('grado_id', 'Grado Id:'); ?>

    <p><?php echo $seccion->grado_id; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $seccion->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $seccion->updated_at; ?></p>
</div>

