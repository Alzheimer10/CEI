<?php $appController = app('App\Services\appController'); ?>
<!-- A Escolar Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('a_escolar', 'Año Escolar:'); ?>

    <?php echo Form::select('a_escolar', $appController->Anos(), null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- Trimestre Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('trimestre', 'Trimestre:'); ?>

    <?php echo Form::select('trimestre', ['ENERO - ABRIL' => 'ENERO - ABRIL', 'MAYO - JULIO' => 'MAYO - JULIO', 'SEPTIEMBRE - DICIEMBRE' =>'SEPTIEMBRE - DICIEMBRE'], null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- Estudiante Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estudiante_id', 'Estudiante:'); ?>

    <?php echo Form::select('estudiante_id', \App\Models\estudiante::all()->pluck('nombre','id'), null, ['class' => 'form-control selectpicker', 'required' => 'true', 'data-live-search' => 'true']); ?>

</div>

<!-- Seccion Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('seccion_id', 'Seccion:'); ?>

    <?php echo Form::select('seccion_id', \App\Models\seccion::all()->pluck('seccion','id'), null, ['class' => 'form-control', 'required' => 'true']); ?>

</div>

<!-- Boleta Field -->


<!-- Url Field -->
<div class="box-body col-sm-12">
    <div class="box">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input id="file" name="file" type="file" required>
    </div>
</div>

<!-- Observacion Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('observacion', 'Observacion:'); ?>

    <?php echo Form::textarea('observacion', null, ['class' => 'form-control', 'maxlength' => '500','rows' => '5', 'title' => 'Maximo de carácteres (500)']); ?>

</div>


<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <?php if( Request::is('boletas/*/edit')): ?>
        <a href="<?php echo route('boletas.index'); ?>" class="btn btn-default"><?php echo app('translator')->getFromJson('app.cancel'); ?></a>
    <?php elseif(Request::is('boletas/create')): ?>
        <a href="<?php echo route('estudiantes.index'); ?>" class="btn btn-default"><?php echo app('translator')->getFromJson('app.cancel'); ?></a>
    <?php else: ?>
        <a href="#" class="btn btn-default" data-dismiss="modal" aria-label="Close">Cancel</a>
    <?php endif; ?>
</div>
