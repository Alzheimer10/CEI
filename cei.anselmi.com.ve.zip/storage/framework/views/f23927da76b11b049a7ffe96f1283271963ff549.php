<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

</div>

<!-- Tlf Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tlf', 'Tlf:'); ?>

    <?php echo Form::text('tlf', null, ['class' => 'form-control']); ?>

</div>

<!-- Estudiante Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('estudiante_id', 'Estudiante Id:'); ?>

    <?php echo Form::text('estudiante_id', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('direccions.index'); ?>" class="btn btn-default">Cancel</a>
</div>
