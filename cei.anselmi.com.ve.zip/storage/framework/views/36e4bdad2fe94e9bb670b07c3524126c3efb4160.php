

<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="box-body">
	    <div class="row">
			<div class="col-xs-12">
				<div class="panel-group" id="accordion">

					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title">
							  <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
							  Agregar Estudiante</a>
							</h4>
						</div>
						<div id="collapse1" class="panel-collapse collapse <?php echo e(Request::is('documentacion/1') ? 'in' : ''); ?>">
							<div class="panel-body">
								<?php echo $__env->make('documentacion.secciones.addEstudiantes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							</div>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title">
							  <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
							  Mostrar los Estudiantes</a>
							</h4>
						</div>
						<div id="collapse2" class="panel-collapse collapse <?php echo e(Request::is('documentacion/2') ? 'in' : ''); ?>">
							<div class="panel-body">
								<?php echo $__env->make('documentacion.secciones.verEstudiantes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>