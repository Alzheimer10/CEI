<?php $__env->startSection('content'); ?>
	<h1>LISTADO COMPLETO</h1>
	<table style="width: 100%">
		<thead>
			<tr>
				<th>nombre</th>
				<th>ci</th>
				<th>edad</th>
				<th>fecha de nacimiento</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr <?php if($index%2 == 0): ?> style="background: #33333326" <?php endif; ?>>
					<td style="text-transform: capitalize;"><?php echo e($estudiante->apellido); ?>, <?php echo e($estudiante->nombre); ?></td>
					<td><?php echo e($estudiante->ci); ?></td>
					<td><?php echo e($estudiante->edad); ?></td>
					<td><?php echo e($estudiante->fechaNacimiento->format('Y-m-d')); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('reportes.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>