<?php echo $__env->make('adminlte-templates::common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<table class="table table-responsive dt-table" id="representantes-table">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Email</th>
            <th>Tlf</th>
            <th>Estudiante</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $representantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $representante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $representante->nombre; ?></td>
            <td><?php echo $representante->email; ?></td>
            <td><?php echo $representante->tlf; ?></td>
            <td><?php echo $representante->estudiante->nombreCompleto; ?></td>
            <td>
                <?php echo Form::open(['route' => ['representantes.destroy', $representante->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('representantes.show', [$representante->id]); ?>" class='btn btn-default btn-xs' title="Ver los datos del representante"><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('representantes.edit', [$representante->id]); ?>" class='btn btn-primary btn-xs' title="Editar datos del representante"><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit','title' => 'Eliminiar representante', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Estas seguro?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
