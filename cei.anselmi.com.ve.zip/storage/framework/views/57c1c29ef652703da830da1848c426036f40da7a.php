<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $representante->id; ?></p>
</div>

<!-- Nombre Field -->
<div class="form-group">
    <?php echo Form::label('nombre', 'Nombre:'); ?>

    <p><?php echo $representante->nombre; ?></p>
</div>

<!-- Email Field -->
<div class="form-group">
    <?php echo Form::label('email', 'Email:'); ?>

    <p><?php echo $representante->email; ?></p>
</div>

<!-- Tlf Field -->
<div class="form-group">
    <?php echo Form::label('tlf', 'Tlf:'); ?>

    <p><?php echo $representante->tlf; ?></p>
</div>

<!-- Estudiante Id Field -->
<div class="form-group">
    <?php echo Form::label('estudiante_id', 'Estudiante Id:'); ?>

    <p><?php echo $representante->estudiante->nombreCompleto; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $representante->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $representante->updated_at; ?></p>
</div>

