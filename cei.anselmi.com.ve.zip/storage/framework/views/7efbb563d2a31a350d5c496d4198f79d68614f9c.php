<table class="table table-responsive" id="direccions-table">
    <thead>
        <tr>
            <th>Email</th>
        <th>Tlf</th>
        <th>Estudiante Id</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $direccions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $direccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $direccion->email; ?></td>
            <td><?php echo $direccion->tlf; ?></td>
            <td><?php echo $direccion->estudiante_id; ?></td>
            <td>
                <?php echo Form::open(['route' => ['direccions.destroy', $direccion->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('direccions.show', [$direccion->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('direccions.edit', [$direccion->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>