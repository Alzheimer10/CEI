<?php echo $__env->make('adminlte-templates::common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<table class="table table-responsive dt-table" id="boletas-table">
    <thead>
        <tr>
            <th>Año</th>
            <th>Trimestre</th>
            <th>Estudiante</th>
            <th>Boleta</th>
            <th>Observación</th>
            <th>Sección</th>
            <th class="text-right">Acción</th>
        </tr>
    </thead>
    <tbody>


    <?php $__currentLoopData = $boletas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boleta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $boleta->a_escolar; ?></td>
            <td><?php echo $boleta->trimestre; ?></td>
            <td><a href="<?php echo e(route('estudiantes.show', $boleta->estudiante->id )); ?>" title="CI: <?php echo e($boleta->estudiante->ci); ?>"><?php echo $boleta->estudiante->nombre; ?> , <?php echo $boleta->estudiante->apellido; ?></a></td>
            
            
            <td><a href="<?php echo e(url('/')); ?><?php echo $boleta->boleta; ?>" target="_blank" title=" <?php echo e($boleta->boleta); ?>"><i class="fa fa-search-plus" aria-hidden="true"></i> VER</a></td>
            <td style="word-break: break-all;"><?php echo $boleta->observacion; ?></td>
            <td><?php echo $boleta->seccion->seccion; ?></td>
            <td class="text-right">
                <?php echo Form::open(['route' => ['boletas.destroy', $boleta->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('boletas.edit', [$boleta->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Estás seguro?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
