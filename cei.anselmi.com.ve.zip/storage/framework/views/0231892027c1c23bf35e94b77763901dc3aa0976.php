<table class="table table-responsive dt-table" id="grados-table">
    <thead>
        <tr>
            <th>Grado</th>
            <th class="text-right">Acciones</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $grados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $grado->grado; ?></td>
            <td class="text-right">
                <?php echo Form::open(['route' => ['grados.destroy', $grado->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('grados.edit', [$grado->id]); ?>" class='btn btn-default btn-xs' title="Modificar grado"><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit','title'=>'Eliminar grado', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Esta seguro?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
