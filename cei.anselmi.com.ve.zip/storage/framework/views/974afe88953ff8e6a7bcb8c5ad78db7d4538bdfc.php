<?php $__env->startSection('content'); ?>

<section class="content">
      <!-- Info boxes -->
    <div class="row">

		<div class="col-md-6">
		  <!-- USERS LIST -->
		  <div class="box box-success">
		    <div class="box-header with-border">
		      <h3 class="box-title">Ultimas modificaciones</h3>

		    	<div class="box-tools pull-right">
		    		<span class="label label-danger">4</span>
		    		<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
		    		</button>
		    		<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
		    		</button>
		    	</div>
		    </div>
		    <!-- /.box-header -->
		    <div class="box-body no-padding">
		    	<ul class="users-list clearfix">
		    		<?php $__currentLoopData = $lastEstudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        		<li>
		        		  <img src="<?php echo e(asset('img/default_avatar.jpg')); ?>" alt="User Image">
		        		  <a class="users-list-name" href="#" title="<?php echo e($estudiante->nombre); ?>, <?php echo e($estudiante->apellido); ?>"><?php echo e($estudiante->nombre); ?>, <?php echo e($estudiante->apellido); ?></a>
		        		  <span class="users-list-date"><?php echo e($estudiante->updated_at); ?></span>
		        		</li>
		    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    	</ul>
		      <!-- /.users-list -->
		    </div>
		    <!-- /.box-body -->
		    <div class="box-footer text-center">
		      <a href="<?php echo e(url('estudiantes')); ?>" class="uppercase">Ver todo los estudiantes</a>
		    </div>
		    <!-- /.box-footer -->
		  </div>
		  <!--/.box -->
		</div>

		<div class="col-md-6">
		  <!-- USERS LIST -->
			<div class="box box-warning">
				<div class="box-header with-border">
				  	<h3 class="box-title">Añadir nueva boleta</h3>

					<div class="box-tools pull-right">
						<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
						</button>
						<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
						</button>
					</div>
				</div>
				<!-- /.box-header -->
				<div class="box-body no-padding">
				    <?php echo Form::open(['route' => 'boletas.store','enctype' => 'multipart/form-data']); ?>

				        <?php echo $__env->make('boletas.fields', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				    <?php echo Form::close(); ?>

				  <!-- /.users-list -->
				</div>
			</div>
		  <!--/.box -->
		</div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>