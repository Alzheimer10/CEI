<table class="table table-responsive dt-table" id="seccions-table">
    <thead>
        <tr>
            <th>Sección</th>
            <th>Grado</th>
            <th class="text-right">Acciones</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $seccions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $seccion->seccion; ?></td>
            <td><?php echo $seccion->grado->grado; ?></td>
            <td class="text-right">
                <?php echo Form::open(['route' => ['seccions.destroy', $seccion->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('seccions.edit', [$seccion->id]); ?>" class='btn btn-default btn-xs' title="Modificar seccion"><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit','title'=>'Eliminar seccion', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Estás seguro?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>