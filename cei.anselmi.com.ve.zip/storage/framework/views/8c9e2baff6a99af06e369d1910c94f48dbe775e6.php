<?php echo $__env->make('adminlte-templates::common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<table class="table display dt-table" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th style="display: none"></th>
            <th>Nombre</th>
            <th>Nacimiento</th>
            <th>Sexo</th>
            <th>Ci</th>
            <th>pago</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="display: none">
                    <input type="checkbox"> 
                </td>
                <td><?php echo $estudiante->nombre; ?>, <?php echo $estudiante->apellido; ?></td>
                <td><b><?php echo $estudiante->fechaNacimiento->format('d-M-y'); ?></b> ( <?php echo e($estudiante->edad); ?> )</td>
                <td><?php echo $estudiante->sexo; ?></td>
                <td><b><?php echo $estudiante->ci; ?></b></td>
                <td>
                    <input id="checkbox-<?php echo $estudiante->id; ?>" class="tgl tgl-danger tgl-on-success" type="checkbox" <?php if( $estudiante->acceso ): ?> checked="checked <?php endif; ?>" style="cursor: pointer;"> 
                    <label for="checkbox-<?php echo $estudiante->id; ?>"  onclick="changeAcceso(<?php echo e($estudiante->acceso); ?>, <?php echo $estudiante->id; ?> )"  title="Control de pago."></label>
                </td>
                <td>
                    <?php echo Form::open(['route' => ['estudiantes.destroy', $estudiante->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('estudiantes.show', [$estudiante->id]); ?>" class='btn btn-default btn-xs' title="Ver los datos del estudiante"><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo route('estudiantes.edit', [$estudiante->id]); ?>" class='btn btn-primary btn-xs' title="Editar datos del estudiante"><i class="glyphicon glyphicon-edit"></i></a>

                        <a href="#" onclick="return modalBoletaEstudiante(<?php echo $estudiante->id; ?>)" class='btn btn-warning btn-xs' title="Añadir nueva boleta"><i class="fa fa-book" aria-hidden="true"></i></a>

                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit','title' => 'Eliminiar estudiante', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Esta seguro?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->startSection('scripts'); ?>
    <script>

        function changeAcceso($checkbox,$id){
            if(confirm('Esta seguro?')){
                if($checkbox==1)
                    var url = "<?php echo e(url('approvedDenied')); ?>"+'/'+$id;
                else
                    var url = "<?php echo e(url('approvedAccess')); ?>"+'/'+$id;
                $.ajax({
                    type: "GET",
                    url: url,
                    cache: false,
                    success: function(data) {
                        $.notify("Estado cambiado", "success");
                     }
                });
            }
        }

    </script>
<?php $__env->stopSection(); ?>