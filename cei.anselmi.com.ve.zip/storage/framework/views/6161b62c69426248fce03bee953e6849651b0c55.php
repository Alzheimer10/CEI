<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/ceiLogin.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="login-logo">
        U.E Luisa del <b>Valle Silva</b>
    </div>
    <div class="login-reg-panel">
        <div class="login-info-box" <?php if( $errors->has('ci') || ( !$errors->has('ci') && !$errors->has('email') && !$errors->has('password') )): ?>  style="display: none" <?php endif; ?>>
            <h2>Soy Representante?</h2>
            <label id="label-register" for="log-reg-show">SI</label>
            <input type="radio" name="active-log-panel" id="log-reg-show" <?php if( $errors->has('ci') || ( !$errors->has('ci') && !$errors->has('email') && !$errors->has('password') )): ?> checked="checked" <?php endif; ?>>
        </div>

        <div class="register-info-box" <?php if( !$errors->has('ci') && ( $errors->has('email') || $errors->has('password') )): ?>  style="display: none" <?php endif; ?>>
            <h2>Soy Administrador?</h2>
            <label id="label-login" for="log-login-show">SI</label>
            <input type="radio" name="active-log-panel" id="log-login-show" <?php if( !$errors->has('ci') && ( $errors->has('email') || $errors->has('password') )): ?> checked="checked" <?php endif; ?>>
        </div>

        <div class="white-panel <?php if( !$errors->has('ci') && ( $errors->has('email') || $errors->has('password') )): ?> right-log <?php endif; ?>">

            <div class="login-show <?php if( $errors->has('ci') || ( !$errors->has('ci') && !$errors->has('email') && !$errors->has('password') )): ?> show-log-panel <?php endif; ?>">
                 <?php echo Form::open(['route' => ['estudiantes.representante'], 'method' => 'get']); ?>

                    <p style="margin-bottom:0px">Representante</p>
                    <h2 style="margin-top: 0px">CEDULA DEL NIÑO</h2>
                    <input type="text" class="form-control" name="ci" value="<?php echo e(old('ci')); ?>" placeholder="CEDULA" required title="Ingrese la cedula correspondiente a su niñ@.">
                        <?php if($errors->has('ci')): ?>
                            <span class="help-block">
                            <strong><?php echo e($errors->first('ci')); ?></strong>
                        </span>
                        <?php endif; ?>
                    <input type="button" value="?" class="hidden-xs pull-left help" style="padding-left: 10px; padding-right: 10px; width: auto" title=" Solo caracteres numéricos. Ejemplo: 123456789">
                    <input type="submit" value="BUSCAR">
                <?php echo Form::close(); ?>

            </div>

            <div class="register-show <?php if( !$errors->has('ci') && ( $errors->has('email') || $errors->has('password') )): ?> show-log-panel <?php endif; ?>">
                <form method="post" action="<?php echo e(url('/login')); ?>">
                    <?php echo csrf_field(); ?>

                    <p style="margin-bottom:0px">Administrador</p>
                    <h2 style="margin-top: 0px">INICIO DE SECCIóN</h2>
                    <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required>
                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <input type="password" class="form-control" placeholder="Password" name="password" required>
                    <?php if($errors->has('password')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                    <input type="button" value="?" class="hidden-xs pull-left help" style="padding-left: 10px; padding-right: 10px; width: auto" title="Esta sección no es para los representante. <br> Ingrese todos los campos.">
                    <input type="submit" value="ENTRAR">
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('resources/tippy/tippy.js')); ?>"></script>
    <script>
        tippy('*:not(.help)',{
            followCursor: true,
        });
        tippy('.help',{
            trigger: 'click'
        });

        $('.login-reg-panel input[type="radio"]').on('change', function() {
            if($('#log-login-show').is(':checked')) {
                $('.register-info-box').fadeOut(); 
                $('.login-info-box').fadeIn();
                
                $('.white-panel').addClass('right-log');
                $('.register-show').addClass('show-log-panel');
                $('.login-show').removeClass('show-log-panel');
                
            }
            else if($('#log-reg-show').is(':checked')) {
                $('.register-info-box').fadeIn();
                $('.login-info-box').fadeOut();
                
                $('.white-panel').removeClass('right-log');
                
                $('.login-show').addClass('show-log-panel');
                $('.register-show').removeClass('show-log-panel');
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>