<?php
header('Location: ./public');
?>