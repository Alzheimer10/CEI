// @koala-prepend '../resources/jquery/jquery.min.js'
// @koala-prepend '../resources/bootstrap/js/bootstrap.min.js'
// @koala-prepend '../resources/icheck.min.js'