// @koala-prepend "jquery.min.js"

// jQuery is ready
$(function(){
  // TODO
})